This is two methods about T-test. 

One called OneSampleT_Test and the other called PariedSampleT_Test.
In the method PariedSampleT_Test, variable temp replace the denominator of the formula.

There are two other simple methods ave and standardDeviation.
ave is used to return the average of a double array
standardDeviation is used to return the standard deviation of a double array

if Unresolved compilation problem happens, please add your package.